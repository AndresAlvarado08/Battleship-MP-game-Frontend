import React from "react";

/** Radar circular, centrado en la VENTANA (viewport), con cono y ping central */
export default function RadarBackground({ size = 640 }: { size?: number }) {
  return (
    // Capa FIJA a pantalla completa => siempre centrado en viewport
    <div className="fixed inset-0 pointer-events-none select-none flex items-center justify-center z-0">
      {/* Contenedor circular que recorta todo lo interno */}
      <div
        className="relative rounded-full overflow-hidden"
        style={{ width: size, height: size }}
        aria-hidden
      >
        {/* Anillos */}
        <div className="absolute inset-0 rounded-full border border-sky-500/35" />
        <div className="absolute inset-[10%] rounded-full border border-sky-500/20" />
        <div className="absolute inset-[22%] rounded-full border border-sky-500/20" />
        <div className="absolute inset-[34%] rounded-full border border-sky-500/20" />

        {/* Cono (haz) — se recorta perfectamente por el overflow-hidden */}
        <div
          className="
            absolute left-1/2 top-1/2
            -translate-x-1/2 -translate-y-1/2
            origin-center animate-radar-rotate
          "
          style={{
            width: size * 1.5,
            height: size * 1.5,
            background:
              "conic-gradient(from 0deg, rgba(56,189,248,.35) 0deg, rgba(56,189,248,.16) 45deg, rgba(56,189,248,0) 65deg)",
            filter: "blur(.45px)",
          }}
        />

        {/* Brillo radial sutil */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(circle at 50% 50%, rgba(56,189,248,.06) 0%, rgba(56,189,248,0) 60%)",
          }}
        />

        {/* Punto central (círculo) + onda */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="w-3 h-3 rounded-full bg-sky-400 relative z-20" />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full animate-radar-ping z-10" />
        </div>
      </div>
    </div>
  );
}
